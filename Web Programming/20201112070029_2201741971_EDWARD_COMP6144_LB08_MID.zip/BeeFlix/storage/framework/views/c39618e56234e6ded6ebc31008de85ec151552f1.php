
<body>
    <div class="header">
        <a href="/" class="logo">BeeFlix</a>
        <div class="header-left">
            <a href="<?php echo e(url()->previous()); ?>">Kembali</a>
            <a href="/">Lihat semua film</a>
        </div>
        
      </div>

        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="row row-title" style="text-align: center"><a href="<?php echo e(route("kategori",[$Genre->id])); ?>"><h2><?php echo e($Genre->name); ?></h2></a></div>
            <hr> 
    <div class="container">
    
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($Genre->id == $Movie->genre_id): ?>
        <div class="movie-card">
            <div class="movie-header"><a href="<?php echo e(route("detail",[$Movie->id])); ?>">
                <img src = "<?php echo e(URL::to('/asset/'.$Movie->photo)); ?> "style="width: 100%; height: 100%;"/></a>
            </div>
            <div class="movie-content-header">
                <a href="<?php echo e(route("detail",[$Movie->id])); ?>">
                    <h3 class="movie-title"><?php echo e($Movie->title); ?></h3>
                </a> 
                <a class="btn btn-primary btn-block" href="<?php echo e(route("detail",[$Movie->id])); ?>" role="button">LIHAT FILM</a>   
            </div>
        </div>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!--container-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </body>
    </html>
<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2201742356\BeeFlix\resources\views/index.blade.php ENDPATH**/ ?>