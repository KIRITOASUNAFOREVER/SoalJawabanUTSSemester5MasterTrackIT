
<div class="header">
    <a href="/" class="logo">BeeFlix</a>
    <div class="header-left">
        <a href="<?php echo e(url()->previous()); ?>">Kembali</a>
        <a href="/">Lihat semua film</a>
    </div>
    
  </div>
  <body>
    <br><br><br><br><br><br>
    <div class="row">
      <div class="column left">
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($Movie->id==$id): ?>
        <br><img src = "<?php echo e(URL::to('/asset/'.$Movie->photo)); ?> "style="width: 200px; height: 300px;"/></td>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="column middle">
        <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($Movie->id==$id): ?>
        <h3><?php echo e($Movie->title); ?></h3>
          <?php for($i = 0; $i < $Movie->rating; $i++): ?>
          <span class="fa fa-star checked"></span>
           <?php endfor; ?>
           <?php for($i = 0; $i <5-$Movie->rating; $i++): ?>
            <span class="fa fa-star"></span>
           <?php endfor; ?>
           <br><br>
        <p><?php echo e($Movie->description); ?></p>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><br>
        kategori: <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route("kategori",[$Kategori->id])); ?>"><?php echo e($Kategori->name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <div class="column right">
        <h3 style="text-align: center">Episode</h3>
        <table id="tablelist">
          <tr>
            <th>Episode</td>
            <th>Judul</th>
          </tr>
          <?php $__currentLoopData = $episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episodes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($episodes->movie_id==$id): ?>
          <tr>
          <td>episode <?php echo e($episodes->episode); ?></td>
          <td><?php echo e($episodes->title); ?></td>
          </tr>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <div class="row">
          <div class="col-12 text-center">
            <?php echo e($episode->links()); ?>

          </div>
        </div>

      </div>
    </div>
  </body>

<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2201742356\BeeFlix\resources\views/detail.blade.php ENDPATH**/ ?>