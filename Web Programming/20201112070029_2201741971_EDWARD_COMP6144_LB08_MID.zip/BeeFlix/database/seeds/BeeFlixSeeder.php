<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BeeFlixSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();

        DB::table('genres')->insert([
            ["id"=>"1","name" => "Drama"],
            ["id"=>"2","name" => "Kids"],
            ["id"=>"3","name" => "TV Show"]
        ]);
        DB::table('movies')->insert([
            //Genre ID 1
            ["id"=>"1"
            ,"genre_id" => "1",
            "title" => "Rain Or Shine",
            "photo" => "RainorShine.jpg",
            "description" => "Setelah kehilangan ayahnya dalam robohnya sebuah mal yang fatal, Gang Du kehilangan semangat hidup dan melalui hidupnya yang kacau hari
            demi hari dengan enggan. Suatu malam, dia dipukuli sampai hampir mati oleh sekelompok orang dan dibuang di sebuah gang sepi. Tepat
            sebelum dia menyerah dengan hidupnya, seorang wanita, Moon Su, menghampirinya.",
            "rating" => "3"],

            ["id"=>"2"
            ,"genre_id" => "1",
            "title" => "Sky Castle",
            "photo" => "SkyCastle.jpg",
            "description" => "Sky Castle: The name of the luxury private town where wealthy doctors and professors live. It was built by the first president of Joo Nam university, which is the best university in Korea. Most of the residents are doctors and law school professors of the university. The drama describes all the ins and outs of how the noblewomen make their children enter the top university. It is a comic satirical drama that closely looks behind the scenes at the materialistic desires of the top upper class parents in Korea, who vigorously push forward their plans to make their family a succession of doctors and lawyers, from father to son.",
            "rating" => "5"],

            ["id"=>"3"
            ,"genre_id" => "1",
            "title" => "Uncontrollably Fond",
            "photo" => "UncontrollablyFond.jpg",
            "description" => "A young couple break up when they realise they are cut from different cloths. Years later, they reunite as completely different people -- he’s an
            egotistical superstar, and she’s a materialistic documentarian with the task of recording his documentary. After an initially rocky start, sparks
            start flying.",
            "rating" => "4"],

            //Genre ID 2
            ["id"=>"4"
            ,"genre_id" => "2",
            "title" => "Cicakman Siri Animasi",
            "photo" => "Cicakman.jpg",
            "description" => "Berdasarkan filem “superhero” No 1 Malaysia, siri animasi Cicakman mengisahkan Hairi bersama rakan-rakannya yang sentiasa berdepan dengan pelbagai cabaran di Metrofulus. Dengan adanya kuasa yang luarbiasa, mampukah Cicakman tumpaskan segala kejahatan terutamanya dalang disebalik segala masalah iaitu Profesor Klon?",
            "rating" => "2"],

            ["id"=>"5"
            ,"genre_id" => "2",
            "title" => "Full-Time Magister Season 1",
            "photo" => "FullTimeMagister1.jpg",
            "description" => "The aloof high schooler Mo Fan has found himself in a universe similar yet distinctly different from his own mundane one; it's a place where magic has replaced the essence of science. Here, the most capable students are taught to master the wonders of spellworking to fend off large devastating beasts that lurk in the forests surrounding the city.",
            "rating" => "4"],

            ["id"=>"6",
            "genre_id" => "2",
            "title" => "Full-Time Magister Season 2",
            "photo" => "FullTimeMagister2.jpg",
            "description" => "The second season of Full-Time Magister. The aloof high schooler Mo Fan has found himself in a universe similar yet distinctly different from his own mundane one; it's a place where magic has replaced the essence of science. Here, the most capable students are taught to master the wonders of spellworking to fend off large devastating beasts that lurk in the forests surrounding the city.",
            "rating" => "4"],

            //Genre ID 3
            ["id"=>"7",
            "genre_id" => "3",
            "title" => "Infinite Challenge",
            "photo" => "InfiniteChallenge.webp",
            "description" => "Saksikanlah saat lima pria jenaka, semua dengan kepribadian yang berbeda, berkumpul untuk acara realitas-ragam ini. Mereka mungkin terlihat bodoh, tapi saat mereka bersama, mereka tidak terkalahkan. Simak saat mereka menghadapi tantangan berbeda setiap minggu dan saksikan bagaimana mereka berusaha mengatasinya.",
            "rating" => "4"],

            ["id"=>"8",
            "genre_id" => "3",
            "title" => "Little Forest",
            "photo" => "LittleForest.webp",
            "description" => "Dari debu-debu halus di taman bermain hingga masalah keluhan suara di apartemen, anak-anak sekarang ini memiliki lebih sedikit alasan untuk menghabiskan waktu dan bermain di luar ruangan. Sebuah pusat penitipan anak ramah lingkungan di hutan kini dibuka untuk anak-anak yang tidak punya tempat untuk berlarian dan bermain dengan bebas. Empat selebritas, Tsundere Lee Seo Jin, Pengasuh anak Lee Seung Gi, Penyemangat Park Na Rae, dan Sentimental Jung So Min, bersama-sama membuat taman untuk anak-anak dan bersenang-senang bersama anak-anak di sana.",
            "rating" => "4"],

            ["id"=>"9",
            "genre_id" => "3",
            "title" => "Player",
            "photo" => "Player.webp",
            "description" => "Player adalah acara tempat para peserta harus menahan tawa selagi melakukan tugas-tugas individu mereka. Setiap pekan, mereka akan ditempatkan dalam situasi berbeda yang tidak mengizinkan mereka untuk tertawa. Setiap kali mereka gagal menahan tawa, honor penampilan mereka akan dikurangi 10 dolar. Para komedian populer seperti Lee Su Geun dan Lee Yong Jin ikut serta dalam pertarungan tawa yang menyenangkan.",
            "rating" => "4"]
        ]);

        DB::table('episodes')->insert([
        //Movie ID 1
            [
                "movie_id" => "1",
                "episode"=>"1",
                "title"=>"Rain or Shine 1"
        ],
            [   
                "movie_id" => "1",
                "episode"=>"2",
                "title"=>"Rain or Shine 2"
        ],        
            [   
                "movie_id" => "1",
                "episode"=>"3",
                "title"=>"Rain or Shine 3"
        ],
            [   
            "movie_id" => "1",
            "episode"=>"4",
            "title"=>"Rain or Shine 4"
        ],
        [   
            "movie_id" => "1",
            "episode"=>"5",
            "title"=>"Rain or Shine 5"
        ],
        [   
            "movie_id" => "1",
            "episode"=>"6",
            "title"=>"Rain or Shine 6"
        ],
        [   
            "movie_id" => "1",
            "episode"=>"7",
            "title"=>"Rain or Shine 7"
        ],
        [   
            "movie_id" => "1",
            "episode"=>"8",
            "title"=>"Rain or Shine 8"
        ],
        [   
            "movie_id" => "1",
            "episode"=>"9",
            "title"=>"Rain or Shine 9"
        ],

        #Movie ID 2
        [   
            "movie_id" => "2",
            "episode"=>"1",
            "title"=>"Sky Castle 1"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"2",
            "title"=>"Sky Castle 2"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"3",
            "title"=>"Sky Castle 3"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"4",
            "title"=>"Sky Castle 4"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"5",
            "title"=>"Sky Castle 5"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"6",
            "title"=>"Sky Castle 6"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"7",
            "title"=>"Sky Castle 7"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"8",
            "title"=>"Sky Castle 8"
        ],
        [   
            "movie_id" => "2",
            "episode"=>"9",
            "title"=>"Sky Castle 9"
        ],

        #Movie ID 3
        [   
            "movie_id" => "3",
            "episode"=>"1",
            "title"=>"Uncontrollably Fond 1"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"2",
            "title"=>"Uncontrollably Fond 2"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"3",
            "title"=>"Uncontrollably Fond 3"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"4",
            "title"=>"Uncontrollably Fond 4"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"5",
            "title"=>"Uncontrollably Fond 5"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"6",
            "title"=>"Uncontrollably Fond 6"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"7",
            "title"=>"Uncontrollably Fond 7"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"8",
            "title"=>"Uncontrollably Fond 8"
        ],
        [   
            "movie_id" => "3",
            "episode"=>"9",
            "title"=>"Uncontrollably Fond 9"
        ],
        #Movie ID 4
        [   
            "movie_id" => "4",
            "episode"=>"1",
            "title"=>"Cicakman 1"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"2",
            "title"=>"Cicakman 2"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"3",
            "title"=>"Cicakman 3"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"4",
            "title"=>"Cicakman 4"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"5",
            "title"=>"Cicakman 5"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"6",
            "title"=>"Cicakman 6"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"7",
            "title"=>"Cicakman 7"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"8",
            "title"=>"Cicakman 8"
        ],
        [   
            "movie_id" => "4",
            "episode"=>"9",
            "title"=>"Cicakman 9"
        ],
        #Movie ID 5
        [   
            "movie_id" => "5",
            "episode"=>"1",
            "title"=>"Full Time Magister 1"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"2",
            "title"=>"Full Time Magister 2"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"3",
            "title"=>"Full Time Magister 3"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"4",
            "title"=>"Full Time Magister 4"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"5",
            "title"=>"Full Time Magister 5"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"6",
            "title"=>"Full Time Magister 6"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"7",
            "title"=>"Full Time Magister 7"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"8",
            "title"=>"Full Time Magister 8"
        ],
        [   
            "movie_id" => "5",
            "episode"=>"9",
            "title"=>"Full Time Magister 9"
        ],
        #Movie ID 6
        [   
            "movie_id" => "6",
            "episode"=>"1",
            "title"=>"Season 2 Episode 1"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"2",
            "title"=>"Season 2 Episode 2"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"3",
            "title"=>"Season 2 Episode 3"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"4",
            "title"=>"Season 2 Episode 4"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"5",
            "title"=>"Season 2 Episode 5"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"6",
            "title"=>"Season 2 Episode 6"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"7",
            "title"=>"Season 2 Episode 7"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"8",
            "title"=>"Season 2 Episode 8"
        ],
        [   
            "movie_id" => "6",
            "episode"=>"9",
            "title"=>"Season 2 Episode 9"
        ],
        #Movie ID 7
        [   
            "movie_id" => "7",
            "episode"=>"1",
            "title"=>"Infinite Challenge 1"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"2",
            "title"=>"Infinite Challenge 2"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"3",
            "title"=>"Infinite Challenge 3"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"4",
            "title"=>"Infinite Challenge 4"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"5",
            "title"=>"Infinite Challenge 5"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"6",
            "title"=>"Infinite Challenge 6"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"7",
            "title"=>"Infinite Challenge 7"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"8",
            "title"=>"Infinite Challenge 8"
        ],
        [   
            "movie_id" => "7",
            "episode"=>"9",
            "title"=>"Infinite Challenge 9"
        ],
        #Movie ID 8
        [   
            "movie_id" => "8",
            "episode"=>"1",
            "title"=>"Little Forest 1"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"2",
            "title"=>"Little Forest 2"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"3",
            "title"=>"Little Forest 3"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"4",
            "title"=>"Little Forest 4"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"5",
            "title"=>"Little Forest 5"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"6",
            "title"=>"Little Forest 6"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"7",
            "title"=>"Little Forest 7"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"8",
            "title"=>"Little Forest 8"
        ],
        [   
            "movie_id" => "8",
            "episode"=>"9",
            "title"=>"Little Forest 9"
        ],
        #Movie ID 9
        [   
            "movie_id" => "9",
            "episode"=>"1",
            "title"=>"Player 1"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"2",
            "title"=>"Player 2"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"3",
            "title"=>"Player 3"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"4",
            "title"=>"Player 4"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"5",
            "title"=>"Player 5"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"6",
            "title"=>"Player 6"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"7",
            "title"=>"Player 7"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"8",
            "title"=>"Player 8"
        ],
        [   
            "movie_id" => "9",
            "episode"=>"9",
            "title"=>"Player 9"
        ]
        ]);
        Schema::enableForeignKeyConstraints();
    }
}
