<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class BeeFlixController extends Controller
{
        public function utama(){
            $film = DB::select('select * from movies');
            $genre = DB::select('select * from genres');
            return view('index',['movies'=>$film,'genres'=>$genre]);
        }
        public function kedua($id){
            $movies = DB::select('select * from movies');
            $episode = DB::table('episodes')->where('movie_id', $id)->paginate(3);
            $kategori = DB::table('movies')
                            ->join('genres', 'movies.genre_id', '=', 'genres.id')    
                            ->where('movies.id', $id);
            $kategori = $kategori->get();
             $key = $id;
             return view('detail',['movies'=>$movies,'episode'=>$episode,'id'=>$key,'kategori'=>$kategori]);
         }
         public function ketiga($id){
            $movies = DB::table('movies')->where('genre_id', $id);
            $movies = $movies->get();
            // $movies = DB::select('select * from movies')->where('genre_id',$id);
            $genres = DB::table('genres')->where('id', $id);
            $genres = $genres->get();
            return view('kategori',['movies'=>$movies,'genres'=>$genres ,'id'=>$id]);
        }
}
