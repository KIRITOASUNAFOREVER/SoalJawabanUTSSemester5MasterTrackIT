@extends('head')
<body>
    <div class="header">
        <a href="/" class="logo">BeeFlix</a>
        <div class="header-left">
            <a href="/">Kembali</a>
            <a href="/">Lihat semua film</a>
        </div>
      </div>

        @foreach ($genres as $Genre)
        {{-- {{route('genres', [$Genre->id])}} --}}
            <div class="row row-title" style="text-align: center"><a href="{{route("kategori",[$Genre->id])}}"><h2>{{$Genre->name}}</h2></a></div>
            <hr> 
    <div class="container">
    
        @foreach ($movies as $Movie)
        @if ($Genre->id == $Movie->genre_id)
        <div class="movie-card">
            <div class="movie-header"><a href="{{route("detail",[$Movie->id])}}">
                <img src = "{{ URL::to('/asset/'.$Movie->photo) }} "style="width: 100%; height: 100%;"/></a>
            </div>
            <div class="movie-content-header">
                <a href="{{route("detail",[$Movie->id])}}">
                    <h3 class="movie-title">{{$Movie->title}}</h3>
                </a> 
                <a class="btn btn-warning btn-block" href="{{route("detail",[$Movie->id])}}" role="button">LIHAT FILM</a>   
            </div>
        </div>

        @endif
        @endforeach
    </div><!--container-->
    @endforeach
    </body>
    </html>