@extends('head')
<div class="header">
    <a href="/" class="logo">BeeFlix</a>
    <div class="header-left">
        <a href="/">Kembali</a>
        <a href="/">Lihat semua film</a>
    </div>
  </div>
  <body>
    <br><br><br><br><br><br>
    <div class="row">
      <div class="column left">
        @foreach($movies as $Movie)
        @if ($Movie->id==$id)
        <br><img src = "{{ URL::to('/asset/'.$Movie->photo) }} "style="width: 200px; height: 300px;"/></td>
        @endif
        @endforeach
      </div>
      <div class="column middle">
        @foreach($movies as $Movie)
        @if ($Movie->id==$id)
        <h3>{{$Movie->title}}</h3>
          @for ($i = 0; $i < $Movie->rating; $i++)
          <span class="fa fa-star checked"></span>
           @endfor
           @for ($i = 0; $i <5-$Movie->rating; $i++)
            <span class="fa fa-star"></span>
           @endfor
           <br><br>
        <p>{{$Movie->description}}</p>

        @endif
        @endforeach<br><br>
        kategori: @foreach($kategori as $Kategori)
        <a href="{{route("kategori",[$Kategori->id])}}">{{$Kategori->name}}</a>
        @endforeach

      </div>
      <div class="column right">
        <h3 style="text-align: center">Episode</h3>
        <table id="tablelist">
          <tr>
            <th>Episode</td>
            <th>Judul</th>
          </tr>
          @foreach($episode as $episodes)
          @if ($episodes->movie_id==$id)
          <tr>
          <td>episode {{ $episodes->episode}}</td>
          <td>{{ $episodes->title }}</td>
          </tr>
          @endif
          @endforeach
        </table>

        <div class="row">
          <div class="col-12 text-center">
            {{$episode->links()}}
          </div>
        </div>

      </div>
    </div>
  </body>
